"""
=============================================================================
FILE: main.py
PROJECT: E-Commerce CLI Chatbot (Phase 2)
PURPOSE: Command-Line Interface (CLI) frontend for the e-commerce system.

This module handles all user-facing interactions:
  - ASCII banner display
  - Main menu navigation
  - Natural language / keyword-based input parsing (NLP layer)
  - Product browsing and detail view
  - Add-to-cart flow
  - Cart view and checkout
  - User profile display
  - Help system

PREREQUISITES:
  - app.py must be running before this file is started.
  - Run `python app.py` in a separate terminal first.

USAGE:
  $ python main.py
=============================================================================
"""

import requests

# ============================================================
# CONFIGURATION
# ============================================================
# Base URL for the Flask backend API.
# Change this if running the server on a different host/port.
BASE = "http://127.0.0.1:5000"

# ============================================================
# ASCII BANNER
# ============================================================
# Multi-line raw string used to display the app logo at startup.
# The 'r' prefix prevents Python from interpreting backslashes.
banner = r'''
 ███████╗ ██████╗ ██████╗ ███╗   ███╗
 ██╔════╝██╔════╝██╔═══██╗████╗ ████║
 █████╗  ██║     ██║   ██║██╔████╔██║
 ██╔══╝  ██║     ██║   ██║██║╚██╔╝██║
 ███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║
 ╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝

            ECOM CLI
====================================
'''


# ============================================================
# HELPER: api_get(path)
# ============================================================
def api_get(path):
    """
    Perform a GET request to the Flask backend.

    BUG FIX: Original code made raw requests.get() calls everywhere
    without any error handling. If the server was down, the app would
    crash with an unhandled ConnectionError.

    This helper centralises error handling for all GET calls.

    Args:
        path (str): API endpoint path, e.g. "/products"

    Returns:
        dict | list | None: Parsed JSON response, or None on failure.
    """
    try:
        res = requests.get(BASE + path, timeout=5)
        res.raise_for_status()
        return res.json()
    except requests.exceptions.ConnectionError:
        print("\n[ERROR] Cannot connect to server. Is app.py running?")
        return None
    except requests.exceptions.Timeout:
        print("\n[ERROR] Server request timed out.")
        return None
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}")
        return None


# ============================================================
# HELPER: api_post(path, payload)
# ============================================================
def api_post(path, payload):
    """
    Perform a POST request to the Flask backend with a JSON body.

    BUG FIX: Same rationale as api_get() — centralised error handling
    prevents crashes when the server is unavailable.

    Args:
        path    (str):  API endpoint path, e.g. "/add"
        payload (dict): Data to send as JSON request body.

    Returns:
        dict | None: Parsed JSON response, or None on failure.
    """
    try:
        res = requests.post(BASE + path, json=payload, timeout=5)
        res.raise_for_status()
        return res.json()
    except requests.exceptions.ConnectionError:
        print("\n[ERROR] Cannot connect to server. Is app.py running?")
        return None
    except requests.exceptions.Timeout:
        print("\n[ERROR] Server request timed out.")
        return None
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}")
        return None


# ============================================================
# show_menu()
# ============================================================
def show_menu():
    """
    Print the main navigation menu to the console.

    Displays five options the user can choose from:
      1. View Products
      2. View Cart
      3. View Profile
      4. Help
      5. Exit

    No parameters. No return value.
    Users can also type natural language (e.g., "show products").
    """
    print("\n========= MAIN MENU =========")
    print("1. View Products")
    print("2. View Cart")
    print("3. View Profile")
    print("4. Help")
    print("5. Exit")
    print("(or type: show / cart / profile / help / exit)")


# ============================================================
# product_flow()
# ============================================================
def product_flow():
    """
    Handle the product browsing and add-to-cart flow.

    Step-by-step:
      1. Fetch all products from GET /products.
      2. Display numbered list with stock counts.
      3. Prompt user to select by number or name.
      4. Display full product details (price, specs, delivery).
      5. Ask if user wants to add to cart.
      6. If yes, prompt for quantity (with input validation).
      7. POST to /add and display result.

    BUG FIXES applied:
      - Input validation for quantity (non-numeric input no longer crashes).
      - Handles partial name matching (e.g. "laptop" matches "Laptop").
      - "back" and "menu" keywords correctly abort any sub-step.
      - API failures (server down) handled gracefully.
      - Out-of-range index selection now shows a clear error.

    Returns:
        None
    """
    # Step 1: Fetch products from backend
    products = api_get("/products")
    if products is None:
        return  # Server error already printed in api_get()

    # Step 2: Display product list
    print("\nAvailable Products:")
    print("-" * 30)
    for i, p in enumerate(products, 1):
        print(f"  {i}. {p['name']:<15} | ₹{p['price']:<8} | Stock: {p['stock']}")
    print("-" * 30)

    # Step 3: Get user selection
    choice = input("\nSelect product (name or number, or 'back'): ").strip().lower()

    # Allow navigation shortcuts
    if choice in ("menu", "back", ""):
        return

    # Step 4: Resolve selection to a product object
    selected = None

    if choice.isdigit():
        # BUG FIX: Original code would throw IndexError for out-of-range numbers.
        index = int(choice) - 1
        if 0 <= index < len(products):
            selected = products[index]
        else:
            print(f"[ERROR] Please enter a number between 1 and {len(products)}.")
            return
    else:
        # BUG FIX: Added partial/case-insensitive name matching.
        # Original code only matched exact names (case-insensitive full match).
        for p in products:
            if choice in p["name"].lower():
                selected = p
                break

    if not selected:
        print("[ERROR] Product not found. Please check the name or number.")
        return

    # Step 5: Display product details
    print("\n--- Product Details ---")
    print(f"  Name     : {selected['name']}")
    print(f"  Price    : ₹{selected['price']}")
    print(f"  Stock    : {selected['stock']} units available")
    print(f"  Delivery : {selected.get('delivery', 'N/A')}")
    print(f"  Specs    : {selected.get('specs', 'N/A')}")

    # BUG FIX: If stock is 0, inform the user and skip add-to-cart prompt.
    if selected['stock'] == 0:
        print("\n[INFO] This product is currently out of stock.")
        return

    # Step 6: Ask whether to add to cart
    action = input("\nType 'add' to add to cart or 'back': ").strip().lower()

    if action != "add":
        return  # User chose not to add; return silently

    # Step 7: Get quantity with input validation
    while True:
        qty_input = input("Enter quantity: ").strip()

        # BUG FIX: Original code used int(input(...)) directly,
        # which would raise ValueError on non-numeric input.
        if not qty_input.isdigit() or int(qty_input) <= 0:
            print("[ERROR] Please enter a valid positive number.")
            continue

        qty = int(qty_input)

        # BUG FIX: Client-side stock check to give immediate feedback
        # before even hitting the server.
        if qty > selected['stock']:
            print(f"[ERROR] Only {selected['stock']} units available.")
            continue

        break  # Valid quantity entered

    # Step 8: Send POST /add request
    result = api_post("/add", {"product": selected["name"], "qty": qty})

    if result:
        # Display friendly message instead of raw dict
        print(f"\n✓ {result.get('msg', 'Done').upper()}")


# ============================================================
# cart_flow()
# ============================================================
def cart_flow():
    """
    Handle the cart display and checkout flow.

    Step-by-step:
      1. Fetch current cart from GET /cart.
      2. If empty, inform user and return.
      3. Display cart contents with a running total.
      4. Prompt for checkout or back.
      5. If checkout, call GET /checkout and confirm.

    BUG FIXES applied:
      - Calculates and displays total cart value (was missing).
      - API failures handled gracefully.
      - Empty cart check before displaying checkout option.

    Returns:
        None
    """
    # Step 1: Fetch cart from backend
    cart = api_get("/cart")
    if cart is None:
        return

    # Step 2: Handle empty cart
    if not cart:
        print("\nYour cart is empty.")
        return

    # Step 3: Display cart items
    # BUG FIX: Original code didn't show prices or totals in the cart view.
    # We now fetch the product list to cross-reference prices.
    products = api_get("/products") or []
    price_map = {p["name"]: p["price"] for p in products}

    print("\n========= YOUR CART =========")
    total = 0
    for item in cart:
        name = item.get("product", "Unknown")
        qty = item.get("qty", 0)
        unit_price = price_map.get(name, 0)
        line_total = unit_price * qty
        total += line_total
        print(f"  {name:<15} x{qty}  @ ₹{unit_price}  = ₹{line_total}")
    print("-" * 35)
    print(f"  {'TOTAL':<24}  ₹{total}")
    print("=" * 35)

    # Step 4: Ask for checkout or back
    action = input("\nType 'checkout' to place order or 'back': ").strip().lower()

    if action == "checkout":
        # Step 5: Process checkout
        result = api_get("/checkout")
        if result:
            print(f"\n✓ {result.get('msg', 'Done').upper()}")
            print("Thank you for shopping with ECOM CLI!")


# ============================================================
# main()
# ============================================================
def main():
    """
    Application entry point. Controls the main event loop.

    Flow:
      1. Print ASCII banner.
      2. Enter infinite loop:
         a. Show main menu.
         b. Read user input.
         c. Apply NLP/keyword matching to determine intent.
         d. Delegate to appropriate flow function.
         e. Repeat until user exits.

    NLP Strategy (keyword matching):
      - "1" or any input containing "show"/"product" → product_flow()
      - "2" or any input containing "cart"           → cart_flow()
      - "3" or any input containing "profile"        → show profile
      - "4" or any input containing "help"           → show help
      - "5" or any input containing "exit"/"quit"    → exit loop

    BUG FIX:
      - Original: `if user == "1" or "show" in user` — this condition
        is always True because `"show" in user` is evaluated as
        `bool("show")` which is always True in Python.
        FIXED to: `if user == "1" or "show" in user or "product" in user`
        using correct conditional logic.
    """
    # Display startup banner
    print(banner)
    print("Welcome to E-Commerce CLI System")
    print("Type menu numbers or natural language commands.")

    # Main event loop
    while True:
        show_menu()

        # Read and normalize user input
        user = input("\nEnter: ").strip().lower()

        # ---- Route: Products ----
        # BUG FIX: Added explicit 'product' keyword alongside 'show'
        if user == "1" or "show" in user or "product" in user:
            product_flow()

        # ---- Route: Cart ----
        elif user == "2" or "cart" in user:
            cart_flow()

        # ---- Route: Profile ----
        elif user == "3" or "profile" in user:
            # Simulated user profile data (no auth system in this version)
            profile = {
                "name": "Alena",
                "phone": "9999999999",
                "email": "alena@example.com",
                "orders": 3
            }
            print("\n========= PROFILE =========")
            for key, val in profile.items():
                print(f"  {key.capitalize():<10}: {val}")
            print("===========================")

        # ---- Route: Help ----
        elif user == "4" or "help" in user:
            print("\n========= HELP =========")
            print("  Commands you can type:")
            print("  - 'show' or '1'    → Browse products")
            print("  - 'cart' or '2'    → View your cart")
            print("  - 'profile' or '3' → View your profile")
            print("  - 'help' or '4'    → Show this help")
            print("  - 'exit' or '5'    → Quit the app")
            print("  - 'back'           → Go back from any screen")
            print("========================")

        # ---- Route: Exit ----
        elif user == "5" or "exit" in user or "quit" in user:
            print("\nGoodbye! Thanks for using ECOM CLI.")
            break

        # ---- Route: Empty input ----
        elif user == "":
            pass  # Do nothing, re-show menu

        # ---- Route: Unrecognized input ----
        else:
            print("[INFO] Unrecognized command. Type 'help' for available commands.")


# ============================================================
# SCRIPT ENTRY POINT
# ============================================================
if __name__ == "__main__":
    """
    Run main() only when this script is executed directly.
    Importing this file will not auto-start the CLI.
    """
    main()
